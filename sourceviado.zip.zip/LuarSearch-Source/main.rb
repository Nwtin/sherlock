while true
  system "ruby index.rb"
end
